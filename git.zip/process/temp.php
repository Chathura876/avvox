<?php

// echo $_POST['jobid'];
// echo " --- ";
// echo $_POST['log'];
// echo " --- ";
// //echo $_POST['description'];

echo "updated";

?>